from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Destination, Log
from .serializers import DestinationSerializer, LogSerializer
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status

class DestinationViewSet(viewsets.ModelViewSet):
    queryset = Destination.objects.all()
    serializer_class = DestinationSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)

    @action(detail=True, methods=['post'])
    def test_destination(self, request, pk=None):
        destination = self.get_object()
        
        return Response({"message": "Test successful for destination."}, status=status.HTTP_200_OK)


class LogViewSet(viewsets.ModelViewSet):
    queryset = Log.objects.all()
    serializer_class = LogSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save()

    def get_queryset(self):
        queryset = Log.objects.all()
        account = self.request.query_params.get('account', None)
        if account is not None:
            queryset = queryset.filter(account__id=account)
        return queryset